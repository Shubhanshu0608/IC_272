# Shubhanshu Agrawal
#B19058
#7987590764

# importing required libraries

import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from scipy import stats
from scipy.stats import pearsonr

# reading csv file with the help of panda
data=pd.read_csv(r'C:\Users\n\Downloads\landslide_data3.csv') #location of file is C:\Users\n\Downloads\landslide_data3.csv

if (data.isnull().values.any()==False):
    print("No Null values in dataframe") # Finding Is there any null value in data or not

print("\n")


print("<<<<<<<<<<<<<<<<<<Question-1>>>>>>>>>>>>>>>>>")

# Making list of all the data columns 
dates=list(data['dates'])
stationid=list(data['stationid'])
temperature=list(data['temperature'])
humidity=list(data['humidity'])
pressure=list(data['pressure'])
rain=list(data['rain'])
lightavgw=list(data["lightavgw/o0"])
lightmax=list(data['lightmax'])
moisture=list(data['moisture'])

G=[temperature,humidity,pressure,rain,lightavgw,lightmax,moisture] # making list of different coloumns which we have to use 

G1=[["temperature","C"],["humidity","%"],["pressure","mb"],["rain","ml"],["lightavgw","lux"],["lightmax","lux"],["moisture","%"]] # Name of attributes and their units 
k=[]
for j in range(len(G)):
    p=[]
    print("for",G1[j][0],"following data is:-")
    print("Mean is :-" ,np.mean(G[j]),G1[j][1]) #calculating Mean
    print("Median is :-" ,np.median(G[j]),G1[j][1]) #calculating Median
    print("Mode is :-" ,*(stats.mode(G[j])[0]),G1[j][1]) #calculating Mode
    print("Minimum is :-",np.min(G[j]),G1[j][1]) # calculating Minimum number 
    print("Maximum is :-",np.max(G[j]),G1[j][1]) # calculating Maximum number
    print("Standard deviation :-",np.std(G[j]),G1[j][1]) #calculating stndard deviation
    print("\n")
    p.append(np.mean(G[j]))
    p.append(np.median(G[j]))
    p.append(*(stats.mode(G[j])[0]))
    p.append(np.min(G[j]))
    p.append(np.max(G[j]))
    p.append(np.std(G[j]))
    k.append(p)
df=pd.DataFrame(k,columns=['mean','median','mode','min','max','std'],index=['temperature',"humidity","pressure","rain","lightavgw","lightmax","moisture"]) # making dataframe for convienienve using pandas 
print(df)


print("<<<<<<<<<<<<<<<<<<<<<<<Question-2>>>>>>>>>>>>>>>>>>>>>>>>>")

print("<<<<<<<<<<<<<<<<<<<<<<<Q(2)(a)>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")


for i in range(len(G)):
    if G[i]!=rain: # plotting scattering curve for rain with other other attributes
        print("Scatter Plot of rain V/S ",G1[i][0])
        plt.scatter(rain,G[i],c="orange")
        plt.title("Scatter Plot of rain V/S Other attributes") # Titling the curve 
        plt.xlabel("rain") #labelling X-axis 
        plt.ylabel(G1[i][0]) #labelling Y-axis
        plt.show()
print("\n")   

print("<<<<<<<<<<<<<<<<<<<<<<<Q(2)(b)>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")

print("\n") 
    
for i in range(len(G)):
    if G[i]!=temperature: # plotting scattering curve for temperature with other attributes
        print("Scatter Plot of temperature V/S ",G1[i][0])
        plt.scatter(temperature,G[i],c="red")
        plt.title("Scatter Plot of temperature V/S Other attributes") # Titling the curve 
        plt.xlabel("temperature") #labelling X-axis
        plt.ylabel(G1[i][0]) #labelling Y-axis
        plt.show()
        
print("\n")   

print("<<<<<<<<<<<<<<<<<<<<<<<Q(3)(a)>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")

print("\n") 
for i in range(len(G)):
    if G[i]!=rain: # Pesrsonr correlation coefficien of rain with other attributes
        p1=pearsonr(rain,G[i])
        print("Pearsonr correlation coefficient of rain and",G1[i][0],"is :",p1[0])
print("\n")   

print("<<<<<<<<<<<<<<<<<<<<<<<Q(3)(a)>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")

print("\n")

for i in range(len(G)):
    if G[i]!=temperature:   # Pesrsonr correlation coefficien of temperature with other attributes
        p1=pearsonr(temperature, G[i])
        print("Pearsonr correlation coefficient of temperature and",G1[i][0],"is :",p1[0])
      
        

print("<<<<<<<<<<<<<<<<<<<<<<<Q(4)>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")

print("\n")
        
print("Histogram of Rain") # Plotting histogram of rain

plt.hist(rain,bins=25,density=True,color="green")
plt.title("Histogram of Rain") # Titling the curve 
plt.xlabel("Rain") # labelling X-axis 
plt.ylabel("frequency") #labelling Y-axis
plt.show()


print('\n')

print("Histogram of Moisture") # Plotting histogram of moisture

plt.hist(moisture,bins=25,density=True,color="yellow")
plt.xlabel("Moisture") # labelling X-axis 
plt.ylabel("frequency") # labelling Y-axis 
plt.title("Histogram of Moisture") # Titling the curve 
plt.show()

print("<<<<<<<<<<<<<<<<<<<<<<<Q(5)>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
print("\n")
Groupby=data.groupby("stationid") # using grouby for grouping the data
stationid=["t6","t7","t7","t8","t9","t10","t11","t12","t13","t14","t15"] # different groups in stationid

for i in stationid:
    print("Histogram of plot group",i," of rain is :-") # Histogram of differnt groups of rain
    a=Groupby.get_group(i)["rain"]
    plt.hist(a,bins=25,density=True,color="cyan")  # Plotting Histogram of differnt groups of rain
    plt.xlabel("Rain") # labelling X-axis
    plt.ylabel("frequency") # labelling Y-axis
    b="histogram of group "+i+ " of rain"
    plt.title(b) # Titling of the curve 
    plt.show()
    print("\n")


print("<<<<<<<<<<<<<<<<<<<<<<<<<<Q(6)>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")

print('\n')

print("BoxPlot of Rain is :-")

plt.boxplot(rain) # plotting box-plot of Rain using boxplot
plt.title("BoxPlot of Rain")
plt.show()
    
print('\n')

print("BoxPlot of Moisture is :-")

plt.boxplot(moisture) # plotting box-plot of Moisture using boxplot
plt.title("BoxPlot of moisture")
plt.show()
    

print("END OF ASSIGNMENT NUMBER-1  :-)")
    



