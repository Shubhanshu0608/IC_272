# Shubhanshu Agrawal
#B19058
#7987590764

#Assgnment-2

# importing required libraries
import math
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from scipy import stats
from scipy.stats import pearsonr

# reading csv file with the help of panda
data1=pd.read_csv(r'pima_indians_diabetes_miss.csv') 
data2=pd.read_csv(r'pima_indians_diabetes_original.csv')

pregs=data1["pregs"]   #Extraction of pregs column
plas=data1["plas"]     #Extraction of plas column
pres=data1["pres"] #Extraction of pres column
skin=data1["skin"]    #Extraction of skin column
bmi=data1["BMI"]    #Extraction of BMI column
test=data1["test"]     #Extraction of test column
pedi=data1["pedi"]      #Extraction of pedi column
age=data1["Age"]     #Extraction of Age column
out=data1["class"]    #Extraction of class column

# question-1

print("<<<<<<<<<<<<<<<<<Question-1>>>>>>>>>>>>>>>>>>>")

x=["pregs","plas","pres","skin","test","BMI","pedi","Age","class"] #appending all the names of the coloumns in one list
y=[pregs.isnull().sum(), plas.isnull().sum(),pres.isnull().sum(),skin.isnull().sum(),test.isnull().sum() , bmi.isnull().sum(), pedi.isnull().sum(), age.isnull().sum(),out.isnull().sum()]  # appending the number of missing values in each attribute
plt.bar(x,y)   #plooting bar graph of missing values with attributes
plt.xlabel("Attribute") #labeling X-axis
plt.ylabel("Number of missing values")  #labelling Y-axis
plt.title("Number of missing values v/s attribute") #titling the curve

plt.show()


print("<<<<<<<<<<<<<<<<<<Question-2(a)>>>>>>>>>>>>>>>>>>")

g=[] # list for deleted tuples
for j in range(len(data1)):
    if(data1.iloc[j].count()<=6): # checking wheter the number of values that are not missing in tuple is less than or equal to 2/3 rd attribute
        
        g.append(j) # appending that element which has to be deleted
print('\n')
print("The total number of tuples deleted:- \n",len(g)) #total number of deleted tuples
print("The row numbers of the deleted tuples:- \n",*g) # row no. deleted

print("<<<<<<<<<<<<<<<<<<Question-2(b)>>>>>>>>>>>>>>>>>>")

dele=[] #list of the deleted elements of target attribute
for j in range(len(data1)):
    if(math.isnan(data1.iloc[j]["class"])==True): # checking wheter there is nan value in class attribute or not
        dele.append(j) # appending the row no. which ha nan value in class attribute
dele1=list(set(dele)-set(g)) # removing all the row no. which is already deleted
dele1.sort()
print(" The total number of tuples deleted \n",len(dele1))
print(" The row numbers of the deleted tuples \n",*dele1)
 
print("<<<<<<<<<<<<<Question-3>>>>>>>>>>>>>>>")       
k=dele1+g # total no. of rows that have to deleted
k.sort()

q=0

for j in range(0,len(k)):
    data1.drop(data1.index[k[j]-q],inplace=True) #removing the rows from the dataframe
    j=j-1
    q+=1
colo=list(data1.columns) # list of the name of the attribute from data1
list1=[] # after removing the required rows checking now the sum of null values in each attribute

for j in colo:
    list1.append(data1[j].isnull().sum()) #appending sum of null values
    print("Attribute:",j,"Number of missing values:",data1[j].isnull().sum())
print("The total number of missing value is",sum(list1))
           
print("<<<<<<<<<<<<<<<<<Question-4(a)(i)>>>>>>>>>>>>>")

# lists of mean,median e.t.c
mean=[]
mean1=[]
median=[]
median1=[]
mode=[]
mode1=[]
std=[]
std1=[]


for j in colo:
    
    mean.append(np.mean(data2[j])) #appending original mean
    median.append(np.median(data2[j])) #appending original median
    mode.append(stats.mode(data2[j])[0]) # appending original mode
    std.append(np.std(data2[j])) # appending original standard deviation

data3=data1.copy() # copy list for inteerpolation

data1["pregs"]=data1["pregs"].fillna(np.mean(pregs)) #filling the missing values with the mean
data1["plas"]=data1["plas"].fillna(np.mean(plas)) #filling the missing values with the mean
data1["skin"]=data1["skin"].fillna(np.mean(skin))  #filling the missing values with the mean
data1["BMI"]=data1["BMI"].fillna(np.mean(bmi))  #filling the missing values with the mean
data1["test"]=data1["test"].fillna(np.mean(test))  #filling the missing values with the mean
data1["pedi"]=data1["pedi"].fillna(np.mean(pedi))  #filling the missing values with the mean
data1["Age"]=data1["Age"].fillna(np.mean(age))  #filling the missing values with the mean
data1["class"]=data1["class"].fillna(np.mean(out))  #filling the missing values with the mean
data1["pres"]=data1["pres"].fillna(np.mean(pres))  #filling the missing values with the mean

z1=0
for j in range(0,len(k)):
    data2.drop(data2.index[k[j]-z1],inplace=True) #removing the rows from the dataframe
    
    z1+=1

for j in colo:
    
    mean1.append(np.mean(data1[j])) # appending calculated mean
    median1.append(np.median(data1[j]))
    mode1.append(stats.mode(data1[j])[0])
    std1.append(np.std(data1[j]))
    
print("\n")
# printing original and calculated values
for j in range(len(x)): 
    print("Attribute:- ",x[j])
    print("\n")
    print("Original Mean:",mean[j])
    print("Calculated Mean:",mean1[j])
    print("\n")
    print("Original Median:",median[j])
    print("Calculated Median:",median1[j])
    print("\n")
    print("Original Mode:",*mode[j])
    print("Calculated Mode:",*mode1[j])
    print("\n")
    print("Original Standard Deviation:",std[j])
    print("Calculated Standard Deviation:",std1[j])
    print('\n')
    
print("<<<<<<<<<<<<<<<<<Question-4(a)(ii)>>>>>>>>>>>>>>>>>>")   

rmse=[]  # list for rmse

for j in range(len(x)):
    rms_sum=0
    for i in range(0,len(data1[x[j]])):
        rms_sum=(data1.iloc[i][x[j]]-data2.iloc[i][x[j]])**2+rms_sum
    if(list1[j]!=0):
        rms=math.sqrt((1/list1[j])*rms_sum) #calculating the rmse value
    else:
        rms=0 #if there were no missing values in the attribute
    rmse.append(rms)
    print("Attribute :-",x[j]," Rmse value :-",rms)
    print("\n")

plt.bar(x,rmse)
plt.xlabel("ATTRIBUTE")
plt.ylabel("RMSE")
plt.title("RMSE with respect to the attributes")
plt.show()


print("<<<<<<<<<<<<<<<Question-4(b)(i)>>>>>>>>>>>>>>>>")



for j in x:
    data3[j]=data3[j].interpolate() # filling value with interpolation
mean2=[]
median2=[]
mode2=[]
std2=[]

for j in colo:
    # appending calculated values whw=en missing value is filled ith the heplp of interpolation
    mean2.append(np.mean(data3[j]))
    median2.append(np.median(data3[j]))
    mode2.append(stats.mode(data3[j])[0])
    std2.append(np.std(data3[j]))

print("\n")
# printing original and calculatd vales
for j in range(len(x)): 
    print("Attribute:- ",x[j])
    print("\n")
    print("Original Mean:",mean[j])
    print("Calculated Mean:",mean1[j])
    print("\n")
    print("Original Median:",median[j])
    print("Calculated Median:",median2[j])
    print("\n")
    print("Original Mode:",*mode[j])
    print("Calculated Mode:",*mode2[j])
    print("\n")
    print("Original Standard Deviation:",std[j])
    print("Calculated Standard Deviation:",std2[j])
    print('\n')
    

print("<<<<<<<<<<<<<<<<<Question-4(b)(ii)>>>>>>>>>>>>>>>>>>")   

rmse0=[] # rms lst for interpolation

for j in range(len(x)):
    sum=0
    for i in range(0,len(data3[x[j]])):
        sum=(data3.iloc[i][x[j]]-data2.iloc[i][x[j]])**2+sum
    if(list1[j]!=0):
        rms1=math.sqrt((1/list1[j])*sum) #calculating the rmse value
    else:
        rms1=0 #if there were no missing values in the attribute
    rmse0.append(rms1)
    print("Attribute :-",x[j]," Rmse value :-",rms1)
    print("\n")

plt.bar(x,rmse0)
plt.xlabel("ATTRIBUTE")
plt.ylabel("RMSE")
plt.title("RMSE with respect to the attributes After filling missing values with interpolation")

plt.show()

print("<<<<<<<<<<<<<<<<Question-5(a)>>>>>>>>>>>>>>>>>>>>>>")

q1_age=np.percentile(data3["Age"],25) # 25% quartile of age
q3_age=np.percentile(data3["Age"],75) # 75% quartile of age
iqr_age=q3_age - q1_age  # inter quartile range of age

q1_bmi=np.percentile(data3["BMI"],25) # 25% quartile of BMI
q3_bmi=np.percentile(data3["BMI"],75) # 75% quartile of BMI
iqr_bmi=q3_bmi- q1_bmi  # Inter quartile range f BMI

age=[] # outliers point of age
bmi=[] # outliers points of BMI
data4=data3.copy()

for j in range(len(data1["Age"])):
    if((data3.iloc[j]["Age"]>(q1_age-iqr_age*1.5) and data3.iloc[j]["Age"]<(q3_age+iqr_age*1.5))==False):#condition to check outliers for the Age attribute
        age.append(data3.iloc[j]["Age"])   
        data4.iloc[j]["Age"]=np.median(data3["Age"])
    if((data3.iloc[j]["BMI"]>(q1_bmi-iqr_bmi*1.5) and data3.iloc[j]["BMI"]<(q3_bmi+iqr_bmi*1.5))==False): #condition to check outliers for the Age attribute
        bmi.append(data3.iloc[j]["BMI"])   
        data4.iloc[j]["BMI"]=np.median(data3["BMI"])  

print("The outliers of the Age :",age)
print("The outliers of the BMI :",bmi)
print("<<<<<<<<<<<<Question-5(b)>>>>>>>>>>>>>>>>>")


plt.boxplot((data3["Age"])) # boxplot of age with outliers
plt.title("Age(with outliers)")
plt.show()

plt.boxplot((data3["BMI"]))
plt.title("BMI(with outliers)") #boxplot of BMI with outliers
plt.show()

plt.boxplot((data4["Age"]))
plt.title("Age(without outliers)") # boxplot of age without outliers
plt.show()

plt.boxplot((data4["BMI"])) #boxplot of bmi witht outliers
plt.title("BMI(without outliers)") 
plt.show()
