# Shubhanshu Agrawal
#B19058
#7987590764

#Assgnment-3

# importing required libraries
import math
import numpy as np
from sklearn.metrics import mean_squared_error
import pandas as pd
from matplotlib import pyplot as plt
from scipy import stats
import statistics
from sklearn.decomposition import PCA
# reading csv file with the help of panda
#-------------------------------------------------------------------------------
data=pd.read_csv(r'landslide_data3 (3).csv')
colo=list(data.columns) # list of the name of the attribute from data1
data1=data.copy() # copying data 
for j in colo[2:]:
    
    
    Q1=np.percentile(data1[j],25) # quartile1
    Q3=np.percentile(data1[j],75) #quartile 3
    Q2=Q3-Q1  # inter-quartile range
    
    for i in range(len(data1[j])):
        if (Q3+1.5*Q2<data1.iloc[i][j])or (Q1-1.5*Q2> data1.iloc[i][j]):
            data1.loc[i,j]=np.median(data1[j]) # giving outlier median value of data

#--------------------------------------------------------------------------------
print("<<<<<<<<<<<<<<<<<<<Question-1(a)>>>>>>>>>>>>>>>>>>>>>")
#
print("Minimum and Maximum value before normalization \n")
for j in colo[2:]:
    print("Minimum value of attruibute:-",j," is :- ",data1[j].min())
    print("Maximum value of attruibute:-",j," is :- ",data1[j].max())
    print("\n")
    
del data1["dates"]  # deleting dates from copied list 
del data1["stationid"]  # deleting stationid from copied list
new= (((data1-data1.min()))/(data1.max()-data1.min())*(9-3))+3
 # calculating new minimum and maximum by method of normalization
for i in colo[2:]:
    maxm=data1[i].max()
    minm=data1[i].min() 
    
    for j in range(len(data1[i])):
        
        data1.loc[j,i]= 3+(((data1.loc[j,i]-minm)/(maxm-minm))*6) #





print("Minimum and Maximum value after normalization \n")
for j in colo[2:]:
    print("Minimum value of attribute:- ",j," After normalization is :-",new[j].min())
    print("Maximum value of attribute:- ",j," After normalization is :-",new[j].max())
    
    print("\n")

#--------------------------------------------------------------------------------
print("<<<<<<<<<<<<<<<<Question-1(b)>>>>>>>>>>>>>>>>>>>>>>>>>")

new_standard=(data1 - data1.mean())/(data1.std()) # making new data after satndardization


print("Mean and standard deviation value before normalization \n")

for j in colo[2:]:
    print("Mean and standard deviation value before normalization",j," is :-" , data[j].mean(), " and ",data[j].std())
    print("\n")
    
    
    
for i in colo[2:]:
    mean=data1[i].mean()
    std1=(data1[i].var())**0.5 
    
    for j in range(len(data1[i])):
        
        data1.loc[j,i]= (data1.loc[j,i]-mean)/std1
print("Mean and standard deviation value Afterr normalization \n")
print("\n")
for j in colo[2:]:
    print("Mean and standard deviation value After normalization",j," is :-" , round(new_standard[j].mean(),3), " and ",round(new_standard[j].std(),3))
    print("\n")

print("\n")


#--------------------------------------------------------------------------------

print("<<<<<<<<<<<<<<<<<<<<<<Question-2>>>>>>>>>>>>>>>>>>>>>>>>>")


print("<<<<<<<<<<<<<<<<<<part(a)>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
covariance=[[6.84806467, 7.63444163], [7.63444163, 13.02074623]]  #given covariance matrix

dataset=np.random.multivariate_normal([0,0], covariance,1000)  # generating 1000 random variable

X=list(dataset[:,0])  # data-1
Y=list(dataset[:,1]) #data-1

plt.scatter(X,Y,color="red")  #plotting datasets
plt.xlabel("x1")
plt.ylabel("x2")
plt.title(" scatter plot of the data samples") # titling the plot
plt.show()

#-------------------------------------------------------------------------------------
print("<<<<<<<<<<<<<<<<<<<<<part(b)>>>>>>>>>>>>>>>>>>>>>>")
eigenvalues,eigenvector=np.linalg.eig(covariance) # ccalculating eigenvalues and eigen vector

eigenvector1=eigenvector[0]
eigenvector2=eigenvector[1]


fig,ax=plt.subplots() # making sub-plot

ax.quiver(0,0,eigenvector1[0],eigenvector1[1],scale=2,color="red")
ax.quiver(0,0,eigenvector2[0],eigenvector2[1],scale=5,color="yellow")
plt.xlabel("x1")
plt.ylabel("x2")
ax.scatter(X,Y)
ax.set_title("Eigen directions (with arrows/lines) onto the scatter plot of data (Refer Figure 1)")
plt.show()

#-------------------------------------------------------------------------------------

print("<<<<<<<<<<<<<<<<<<<<<<part(c)>>>>>>>>>>>>>>>>>>>>>>>>>>>")
#Project the data on to the first and second Eigen direction individually and draw both the scatter plots superimposed on Eigen vectors 
for j in range (2):
    projec_matrix=np.outer(eigenvector[j],eigenvector[j].T) 
    projected=   np.dot(projec_matrix,dataset.T).T  # projecting datasets on vectors
    x1=list(projected[:,0]) # list of projected datas
    y1=list(projected[:,1]) # list of 1st featres of projected plots
    fig, ax = plt.subplots()
    ax.scatter(X,Y,color="orange")
    plt.axis([-8,8,-5,5])
    ax.scatter(x1,y1,color="yellow")
    ax.quiver(0,0,eigenvector[0][0],eigenvector[0][1],scale=5,color="red")
    ax.quiver(0,0,eigenvector[1][0],eigenvector[1][1],scale=5,color="red")
    plt.xlabel("x1")
    plt.ylabel("x2")
    plt.show()

#-------------------------------------------------------------------------------------
print("<<<<<<<<<<<<<<<<<<<<<<part(d)>>>>>>>>>>>>>>>>>>>>>>>>>>>")

#Reconstruct the data samples using both eigenvectors, say it 𝐃𝐃�. Estimate thereconstruction error between 𝐃𝐃� and D using mean square error.

projected1=(np.dot(eigenvector,eigenvector.T))
reconstructed=pd.DataFrame(np.dot(projected1,dataset.T).T)
error1=mean_squared_error(dataset, reconstructed)
print(" The reconstruction error between 𝐃𝐃� and D using mean square error :-",error1)

   
    
    
#-------------------------------------------------------------------------------------
print("<<<<<<<<<<<<<<<Question-3>>>>>>>>>>>>>>>>>>>>>>>>>")

#-------------------------------------------------------------------------------------
data3=data1.iloc[:,] # using data for this question we obtained after 1(b)

cor_matrix=data3.corr() # generationg correlation matrix of dataframe

eigvalue,eigvector=np.linalg.eig(cor_matrix) # claculating  eigen vakue and eigen vector

pca_structure=PCA(n_components=2)
pca_data=pca_structure.fit_transform(data3)
pca_data_frame=pd.DataFrame(data = pca_data, columns = ['principal component 1', 'principal component 2'])
      # generating a new dataframe of values as generted from pca_data
print(pca_data_frame)
print("Variance of principal component 1 is :-",round(pca_data_frame["principal component 1"].var(),3))  # printing variance for principal component 1 
print("Eigen Value corresponding  to  principal component 1 is :-",round(sorted(eigvalue,reverse=True)[0],3)) #printing eigen values correspoinding to principal component 1

print("\n")             
print("Variance of principal component 2 is :-",round(pca_data_frame["principal component 2"].var(),3))  # printing variance for principal component 2
print("Eigen Value corresponding  to  principal component 2 is :-",round(sorted(eigvalue,reverse=True)[1],3)) #printing eigen values correspoinding to principal component 2

x_axis=pca_data_frame.loc[:,"principal component 1"] # making list of principal component 1
y_axis=pca_data_frame.loc[:,"principal component 2"] # makinf list of values of principal component 2

plt.scatter(x_axis,y_axis,color="pink")
plt.title("scatter plot of reduced dimensional data")
plt.xlabel("principal component 1")
plt.ylabel("principal component 2")
plt.show()

#-------------------------------------------------------------------------------------

print("<<<<<<<<<<<<<<<<<<<<<<<part(b)>>>>>>>>>>>>>>>>>>>>>>>>>>>")

x=[]
for j in range(len(eigvalue)):
    eigvalue[j]=round(eigvalue[j],3)
    x.append(j)

eigvalue=sorted(eigvalue,reverse=True)
print("All the eigenvalues in the descending order are =>>>",*eigvalue)
y=eigvalue

plt.bar(x,y,color="yellow")
plt.title("All the eigenvalues in the descending order")
plt.show()


#-------------------------------------------------------------------------------------
print("<<<<<<<<<<<<<<<<<<<<<<<part(c)>>>>>>>>>>>>>>>>>>>>>>>>>>>")

X=[]
Y=[]
for j in range(1,8):
    X.append("l="+str(j))
    pca=PCA(n_components=j) # generatind i structures
    
    colum=[]
    for i in range(j):
        colum.append("Principal component"+str(i))
    pca_data=pca.fit_transform(data3)
    pca_data_frame=pd.DataFrame(data = pca_data, columns=colum) # making dataframe of pca
    New_data=pca.inverse_transform(pca_data)
    
    error=(mean_squared_error(New_data,data3)**0.5)
    Y.append(error)
plt.bar(X,Y,color="orange")
plt.xlabel("Value of l")
plt.ylabel("Error at respective value of l")

plt.title( "The reconstruction errors in terms of RMSE considering the different values of l")
plt.show()

#-------------------------------------------------------------------------------------