# Shubhanshu Agrawal
#B19058
#7987590764

#Assgnment-4

# importing required libraries
import math
import numpy as np
from sklearn.metrics import mean_squared_error
import pandas as pd
from matplotlib import pyplot as plt
from sklearn.model_selection import train_test_split
from scipy import stats
import statistics
from sklearn.decomposition import PCA
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix, accuracy_score


data=pd.read_csv(r"seismic_bumps1.csv") # reading the file data

data=data.drop("nbumps",axis=1) # removing useless coloumns
data=data.drop("nbumps2",axis=1)
data=data.drop("nbumps3",axis=1)
data=data.drop("nbumps4",axis=1)
data=data.drop("nbumps5",axis=1)
data=data.drop("nbumps6",axis=1)
data=data.drop("nbumps7",axis=1)
data=data.drop("nbumps89",axis=1)

data=data.groupby("class") # using groupby function to get data by class attribute
sp=data.get_group(0)  # getting data of class 0
d=sp["class"]  # list of 0 class 
[sp_train, sp_test, d_train, d_test] =train_test_split(sp, d, test_size=0.3, random_state=42,shuffle=True)
#using inbuilt functon to split the data into 70 % train data and 30 % test data+

sk=data.get_group(1) # getting data of class 1
k=sk["class"] # list of 0 class 
[sk_train, sk_test, k_train, k_test] =train_test_split(sk, k, test_size=0.3, random_state=42,shuffle=True)
#using inbuilt functon to split the data into 70 % train data and 30 % test data+


frames1=[sp_train,sk_train]  # listing the train data of class 0 amd class 1
frames2=[sp_test,sk_test]  #listing thetest data of class 0 and class 1
frames3=[d_train,k_train]  # listing train data of attribute classes
frames4=[d_test,k_test]     # listing test data of attribute class
X_train=pd.concat(frames1) #training data of each class
X_test=pd.concat(frames2)  # test data of each class
Y_train=pd.concat(frames3)  #training data for each class 
Y_test=pd.concat(frames4) # test data for each each class


s_train=X_train.copy()

#[X_train, X_test, Y_train, Y_test] =train_test_split(X, Y, test_size=0.3, random_state=42,shuffle=True)
#using inbuilt functon to spit the data into 70 % train data and 30 % test data+

#X_train.to_csv("seismic-bumps-train.csv ") # making new-csv file of train data
#X_test.to_csv("seismic-bumps-test.csv ") #making new-csv file for test data
X_train=X_train.drop("class",axis=1) #dropping the attribute classfrom train data
X_test=X_test.drop("class",axis=1)  #dropping the attribute classfrom train data



#--------------------------------------------------------------------------------------------------------------
print("QUESTION-1 \n")

print("part A")

l=[1,3,5]

for j in l:

    classifier = KNeighborsClassifier(n_neighbors=j)    # by this step we are deciding the value of K-NN          
    classifier.fit(X_train,Y_train)   # fitting the training data 
    
    Y_pred=classifier.predict(X_test) # predicting the value for test cases
    
    print("CONFUSION-MATRIX for k= ",j,"\n") 
    
    print(confusion_matrix(Y_test, Y_pred),"\n") # printing the confusion matrix 
    
#--------------------------------------------------------------------------------------------------------------
print("part B \n")

acc=[]
for j in l:

    classifier = KNeighborsClassifier(n_neighbors=j)    # by this step we are deciding the value of K-NN          
    classifier.fit(X_train,Y_train)   # fitting the training data 
    
    Y_pred=classifier.predict(X_test) # predicting the value for test cases
    accuracy=accuracy_score(Y_test, Y_pred)
    print("Classification-Accuracy for k= ",j, ":-  \n")
    print(accuracy.round(3),"\n")
    acc.append(accuracy.round(3))



print("Maximum value of calassification-Accuracy is :- ",max(acc),"\n")
b=acc.index(max(acc))
print("The value of K for which the accuracy is high is:-",l[b],"\n")        
        
#--------------------------------------------------------------------------------------------------------------        
print("Question-2 \n")


X_train1=(X_train-X_train.min())/((X_train.max()-X_train.min()))
X_test1=(X_test-X_train.min())/((X_train.max()-X_train.min()))  

#X_train1.to_csv("seismicbumps-train-Normalised.csv ") # making new-csv file of train data
#X_test1.to_csv("seismicbumps-test-Normalised.csv ")



print("part-A \n")

for j in l:

    classifier = KNeighborsClassifier(n_neighbors=j)    # by this step we are deciding the value of K-NN          
    classifier.fit(X_train1,Y_train)   # fitting the training data 
    
    Y_pred=classifier.predict(X_test1) # predicting the value for test cases
    
    print("CONFUSION-MATRIX for k= ",j,"\n") 
    
    print(confusion_matrix(Y_test, Y_pred),"\n") # printing the confusion matrix 

#--------------------------------------------------------------------------------------------------------------
print("part B \n")

acc1=[]
for j in l:

    classifier = KNeighborsClassifier(n_neighbors=j)    # by this step we are deciding the value of K-NN          
    classifier.fit(X_train1,Y_train)   # fitting the training data 
    
    Y_pred=classifier.predict(X_test1) # predicting the value for test cases
    accuracy=accuracy_score(Y_test, Y_pred)
    print("Classification-Accuracy for k= ",j, ":-  \n")
    print(accuracy.round(3),"\n")
    acc1.append(accuracy.round(3))



print("Maximum value of calassification-Accuracy is :- ",max(acc1),"\n")
b=acc1.index(max(acc1))
print("The value of K for which the accuracy is high is:-",l[b],"\n")     
        
#--------------------------------------------------------------------------------------------------------------        
s_train=s_train.groupby("class")
train0=s_train.get_group(0) # training data for class 0

train1=s_train.get_group(1) # trainig data for class 1    

test=X_test.copy()    #test data

train0=train0.drop("class",axis=1) #dropping class attribute from train data 0

train1=train1.drop("class",axis=1)  # dropping class attribute from train data 1
# finding all the required values that is required for calculating thelikelihood function
mean0=train0.mean() # mean vector for train data of class 0
mean1=train1.mean() # mean vector for train data of class 1

# covariance of train data of class 0 and 1 respectively
covar0=np.cov(train0.transpose()).round(3)
covar1=np.cov(train1.transpose()).round(3)

# determinant of both the covvariance matrix rise to power (-0.5) for respective class

decovar0=(np.linalg.det(covar0))**(-0.5)
decovar1=(np.linalg.det(covar1))**(-0.5)

# inerse matrix for each class


invcovar0=np.linalg.inv(covar0)
invcovar1=np.linalg.inv(covar1)

# calculating constant for likelihood her d=10 sp d/2=5

w=1/(2*math.pi)**5

predicted_list=[]

for j in range(len(test)):
    # calculating the likelihood for class 0
    l0=np.array(test.iloc[j]-mean0)   
    lt=l0.transpose()
    L0=np.dot(lt,invcovar0)
    L01=np.dot(L0,l0)
    
    likelihood_0=w*decovar0*(math.exp(-0.5*L01)) # likelihhod for class 0
    
    count_0=list(Y_train).count(0)
    prob_count_0=count_0/len(list(Y_train)) # prior probability of 0
    
    post_prob_0=likelihood_0*prob_count_0 # posterior probability of classs 0
    
     # calculating the likelihood for class 0
    
    l1=np.array(test.iloc[j]-mean1)   
    l1t=l1.transpose()
    L1=np.dot(l1t,invcovar1)
    L10=np.dot(L1,l1)
    
    likelihood_1=w*decovar1*(math.exp(-0.5*L10)) # likelihhod for class 0
    
    count_1=list(Y_train).count(1)
    prob_count_1=count_1/len(list(Y_train)) # prior probability of 0
    
    post_prob_1=likelihood_1*prob_count_1 # posterior probability of classs 0
      
    # We are not dividing with the evidence in posterior probability because it will be same for both likelihhod
    
    if (post_prob_1<post_prob_0):
        predicted_list.append(0)
    else:
        predicted_list.append(1)

# confusion matrix
print("\nQ3:")
print("\nConfusion matrix for Naive Gaussian model")
print(confusion_matrix(Y_test, predicted_list)) # printing confusionmatrix for gaussian model
    
# accuracy score    
print("\naccuracy score for naive gaussian model is :",end = " ")
y = (accuracy_score(Y_test,predicted_list ).round(5)) 
print(y)
        

#--------------------------------------------------------------------------------------------------------------        

print("\nQ4:")
accuracy_sc = [max(acc),max(acc1),y]
classifier_type = ["knn without normalisation classifier", "knn with noramlisation classifier", "naive gaussian classifier"]

print()
for i in range(3):
    print(classifier_type[i],'has',accuracy_sc[i], 'accuracy score')
xmax = max(accuracy_sc)
ind = accuracy_sc.index(xmax)
print("\nmaximum accuracy is coming out to be equal to:", xmax,"for",classifier_type[ind])
        
       
#--------------------------------------------------------------------------------------------------------------   
        
      
