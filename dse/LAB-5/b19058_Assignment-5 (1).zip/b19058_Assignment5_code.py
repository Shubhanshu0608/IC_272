"""
Shubhanshu Agrawal
B19058
7987590764
"""
# importing required libraries
import math
import numpy as np
from sklearn.metrics import mean_squared_error
import pandas as pd
from matplotlib import pyplot as plt
from sklearn.model_selection import train_test_split
from scipy import stats
import statistics
from sklearn.decomposition import PCA
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix, accuracy_score
from sklearn import metrics
from sklearn.mixture import GaussianMixture
from sklearn.linear_model import LinearRegression 
from sklearn.preprocessing import  PolynomialFeatures 
#-------------------------------------------------------------------------------------------
    
print("part A \n")
    
print("Question-1 \n")  

X_train = pd.read_csv(r"seismic-bumps-train.csv") # extracting training data from csv file 
X_test = pd.read_csv(r"seismic-bumps-test.csv")  # extracting test data from csv file 
#X_train.drop(X_train.columns[[0]], axis = 1, inplace = True)
#X_test.drop(X_test.columns[[0]], axis = 1, inplace = True)
#X_train=X_trin.drop()

X_train_10=X_train.groupby("class")  # grouping the training data by class
X_train_0=X_train_10.get_group(0)  # data for class-0
X_train_1=X_train_10.get_group(1)  #data for class-1
a=[2,4,8,16] # the values of Q
acc=[] # accuracy value for each value of Q
for j in a:
    predicted_list=[] # predicting the test cases
    Gmm_0= GaussianMixture(n_components = j,random_state=42) 
    Gmm_0.fit(X_train_0.iloc[:, :-1])
    ans_0=Gmm_0.score_samples(X_test.iloc[:,:-1])
    prior_class_0=len(X_train_0)/(len(X_train_0)+len(X_train_1))
    
    Gmm_1= GaussianMixture(n_components = j,random_state=42)
    Gmm_1.fit(X_train_1.iloc[:, :-1])
    ans_1=Gmm_1.score_samples(X_test.iloc[:,:-1])
    prior_class_1=1-prior_class_0
    
    for _ in range(len(ans_0)):
        if math.exp(ans_0[_])*prior_class_0>math.exp(ans_1[_])*prior_class_1:
            predicted_list.append(0)
        else:
            predicted_list.append(1)
    confusion=confusion_matrix(X_test["class"],predicted_list)
    accu=accuracy_score(X_test["class"],predicted_list)*100
    accu=accu.round(3)
    print("confusion matrix for value of k=",j," is:- \n",confusion)
    print("\n accuracy for value of k=",j," is",accu)
    acc.append(accu)
            
print("maximum accuracy is ",max(acc)," for value of k= ",a[acc.index(max(acc))])
    
#-------------------------------------------------------------------------------------------

print("\n Question-2 \n")

accuracy_max = [93.17, 92.912, 87.5, max(acc)*100] # from assignment 4
type_ = ['knn without normalisation classifier', 'knn with noramlisation classifier', 'naive gaussian classifier', 'Bayes classifier using GMM'] # from assignment 4


for j in range(4):
    print(type_[j],'has',accuracy_max[j], 'accuracy score')

print("\nmaximum accuracy is coming out to be equal to:", max(accuracy_max),"for",type_[accuracy_max.index(max(accuracy_max))])



#-------------------------------------------------------------------------------------------
print("part B \n")
data=pd.read_csv(r"atmosphere_data.csv") #reading csv file
data1=data.copy() #copying dat

Y=data1["temperature"]
data1=data1.drop("temperature",axis=1)

# splitting data into test data and training data
[X_train, X_test, y_train, y_test] = train_test_split(data1, Y, test_size=0.30, random_state=42)

#X_train.to_csv("atmosphere-train.csv")
#X_test.to_csv("atmosphere-test.csv")
#-------------------------------------------------------------------------------------------

print("Question-1 \n")
print("part-a")
y_train=pd.DataFrame(y_train, columns=['temperature']) # MAKING DATAFRAME OF TEMPERATURE TRAINING DATA

y_test=pd.DataFrame(y_test, columns=['temperature'])  # MAKING DATAFRAME OF TEMPERATURE TESTY DATA

X_pressure_train=X_train["pressure"] # TAKING TRAINING DATA OF PRESSURE ATTRIBUTE
X_pressure_test=X_test["pressure"]  # TAKING TEST DATA OF PRESSURE ATTRIBUTE
X_pressure_train=pd.DataFrame(X_pressure_train, columns=['pressure'])  # MAKING DATAFRAME OF PRESSURE TRAINING DATA
X_pressure_test=pd.DataFrame(X_pressure_test, columns=['pressure']) # MAKING DATAFRAME OF PRESSURE TEST DATA

# PERFORMING SIMPLE LINEAR REGRESSION USING REGRESSOR
regressor = LinearRegression() 
regressor.fit(X_pressure_train, y_train) # FITTING THETRAININGDATA IN REGFRESSOR
predict_train=regressor.predict(X_pressure_train)# PREDICTING THE VALUE OF TEMPERATURE FOR TEST DATA OF PRESSURE WITH THE HELP OF REGRESSOR
predict_test=regressor.predict(X_pressure_test)
plt.scatter(X_pressure_train,y_train) # PLOTTING THE SCATTER CURVE OF TRAINING DATA
plt.plot(X_pressure_train,predict_train,color="red") # FITTINFG THE STRAIGHT LINE
plt.title('Pressure vs Temprerature')
plt.xlabel('Presseure')
plt.ylabel('Temperature')
plt.show()


#-------------------------------------------------------------------------------------------
# Find the prediction accuracy on the training data using root mean squared error
print("part-b \n GRPH")

predict_train=regressor.predict(X_pressure_train)

print('Root Mean Squared Error:', np.sqrt(metrics.mean_squared_error(y_train, predict_train)))
#printing root-mean-squared error



#-------------------------------------------------------------------------------------------

print("part-c \n")

print('Root Mean Squared Error:', np.sqrt(metrics.mean_squared_error(y_test, predict_test)))
#printing root-mean-squared error

#-------------------------------------------------------------------------------------------

print("\n part-d \n")

plt.scatter(y_test,predict_test, color="brown") #plotting test data vs predicted data
plt.title(' actual temperature  vs predicted temperature ')
plt.xlabel('actual temperature ')
plt.ylabel('predicted temperature')
plt.show()

#-------------------------------------------------------------------------------------------

print("QUESTION_2 \n")
print("part-a \n")
p=[2,3,4,5]
rmse_train=[]

for j in p:
    polynomial_features = PolynomialFeatures (degree=j) #giving the degree to the polynomial
    x_poly = polynomial_features.fit_transform(X_pressure_train) # fitting the training data into polynomial
    regressor = LinearRegression()
    regressor.fit(x_poly, y_train) #fitting polynomial data and trin data of class in regressor
    y_pred_train=regressor.predict(polynomial_features.fit_transform(X_pressure_train))
    
    rmse_value=np.sqrt(metrics.mean_squared_error(y_train, y_pred_train))
    rmse_train.append(rmse_value)
   
# plotting root mean square value for every polynomial degree
plt.bar(p,rmse_train,color="red")
plt.xlabel("Value of p")
plt.ylabel("root-mean-square-error")
plt.show()

#-------------------------------------------------------------------------------------------
print("part-b \n")

rmse_test=[]
rms=[]
for j in p:
    polynomial_features = PolynomialFeatures (degree=j)
    x_poly = polynomial_features.fit_transform(X_pressure_train)
    regressor = LinearRegression()
    regressor.fit(x_poly, y_train) 
    y_pred_test=regressor.predict(polynomial_features.fit_transform(X_pressure_test))
    rms.append(y_pred_test)
    rmse_value=np.sqrt(metrics.mean_squared_error(y_test, y_pred_test))
    rmse_test.append(rmse_value)    
   
# plotting root mean square value for every polynomial degree
plt.bar(p,rmse_test,color="orange")
plt.xlabel("Value of p")
plt.ylabel("root-mean-square-error")
plt.show()

#-------------------------------------------------------------------------------------------
print("part-c \n")
# Root mean square error is minimum at p=5 for test data
polynomial_features = PolynomialFeatures (degree=5)
x_poly = polynomial_features.fit_transform(X_pressure_train)
regressor = LinearRegression()
regressor.fit(x_poly, y_train) 
y_pred_test=regressor.predict(polynomial_features.fit_transform(X_pressure_test))
X_pressure_test=np.array(X_pressure_test)
q=np.polyfit((X_test.iloc[:,1]),y_pred_test,5)

rang= np.linspace(X_train.iloc[:,1].min(),X_train.iloc[:,1].max(),300).reshape(-1,1)
plt.scatter(X_pressure_train,y_train)
plt.plot(rang,np.polyval(q,rang),color="red")

plt.title('Polynomial Regression') 
plt.xlabel('Pressure') 
plt.ylabel('Temperature') 
plt.show()
#-------------------------------------------------------------------------------------------

print("part d \n")
plt.scatter(y_test,rms[-1])
plt.title('actual tempeature vs predicted Temprerature')
plt.xlabel('actual temperature')
plt.ylabel('predicted Temperature')

#-------------------------------------------------------------------------------------------
import sklearn
print(sklearn.__version__)


