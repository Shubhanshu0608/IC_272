# Shubhanshu Agrawal
#B19058
#7987590764

#Assgnment-3

# importing required libraries
import math
import numpy as np
from scipy.stats import pearsonr
from sklearn.metrics import mean_squared_error
import pandas as pd
from matplotlib import pyplot as plt
from scipy import stats
import statistics
from sklearn.decomposition import PCA
from statsmodels.graphics.tsaplots import plot_acf
import statsmodels.api as sm 
from statsmodels.tsa.ar_model import AutoReg 
# reading csv file with the help of panda
#-------------------------------------------------------------------------------
print("QUESTION-1 :- \n")
print("PART-a \n")
data=pd.read_csv(r'datasetA6_HP.csv') # reading csv file
t=data["HP"] # making series of data for e part
Y=data["HP"] 

Y=list(Y) #making list for further questions
X=[int(x) for x in range(500)] # indexinx the day
plt.plot(X,Y,color="red") # plot with x-axis as index of the day and y-axis as power consumed in mega units (MU)
plt.xlabel("index of the day")
plt.ylabel(" power consumed ")
plt.title(" line plot  index of the day V\S power consumed")
plt.show()
#-------------------------------------------------------------------------------
print("PART-b \n")
X1=Y[0:499] # Generating  another time sequence with one day lag
X2=Y[1:500] # According to new time lag our original data

AR=pearsonr(X1,X2) #calculation pearsonr coorelation coefficient
print(AR[0].round(3))
#-------------------------------------------------------------------------------
print("PART-c \n")

plt.scatter(X2,X1,color="cyan") # a scatter plot between given time sequence and one day lagged generated sequence 
plt.title("scatter plot between given time sequence and one day lagged generated sequence ")
plt.show()
print("YES IT MATCHED WITH THE CALCULATED VALUE AS WE CAN CLEARLY SEE THAT FROM THE GRAPH THAT OUR ORIGINAL DATA AND ONE DAY LAGGED DATA RE HIGHY CORRELATED AND OUR CORRELATION VALUE IS ALSO HIGH SO IT MATCHES")
#-------------------------------------------------------------------------------
print("PART-d \n")

p=[1,2,3,4,5,6,7] #  different lag values (1 day, 2 days, 3 days upto 7 days).
AR_l=[] #list for storing the correlated values
for j in p:
    print("\n for time sequence ",j,":- ")
    S=Y[0:500-j] # Generating  another time sequence with j day lag
    S1=Y[j:500] # According to new time lag our original data
    w=pearsonr(S,S1) # calculating correlation coefficient
    print(" Pearson correlation (autocorrelation) coefficient between generated time sequences and the given time sequence is",w[0])
    AR_l.append(w[0])
plt.plot(p,AR_l,color="green") #line plot between obtained correlation coefficients (on y-axis) and lagged values (on x-axis).
plt.xlabel(" lagged values")
plt.ylabel("correlation coefficients ")
plt.title("line plot between obtained correlation coefficients (on y-axis) and lagged values (on x-axis).")
plt.show()
#-------------------------------------------------------------------------------
print("PART-e \n")

plot_acf(t,lags=7) #by Using python inbuilt function ‘plot_acf’ to generate the line plot 
plt.show()
print("FROM THE ABOVE GAPH FROM PLOT_aCF WE CAN CLEARLY SEE THAT AS WE INCREASES THE VALUE OF LAGGED DAS THE AUTOCORRELATIO COEFFICIENT DECREASES.")
#-------------------------------------------------------------------------------
print("QUESTION-2 :- \n")


load1=t.values # generaating load data 
train, test = load1[1:len(load1)-250], load1[len(load1)-250:]  #diving load data into test data and train data in length of 250-250 datasets
predicted=[] #list for predicting test values
predicted.append(train[-1]) #lag by 1 
for j in range(len(test)-1):
    predicted.append(test[j]) #predicting the test data
rmse = math.sqrt(mean_squared_error(test, predicted)) #calculating rmse error 
print("\n2.)  the rmse value for predicted and original value of test data using persistence model is: %.3f" %rmse)

#-------------------------------------------------------------------------------
print("QUESTION-3 :- \n")
print("PART-a \n")

load=t.values # generaating load data

train, test = load[1:len(load)-250], load[len(load)-250:]  #dividing in train and test data
#using auto regression model
model = AutoReg(train, lags=5) 
model_fit = model.fit() 
predictions = model_fit.predict(start=len(train), end=len(train)+len(test)-1, dynamic=False) 

rmse1= (mean_squared_error(test, predictions))**0.5
rmse1=rmse1.round(3)
print("Test RMSE ", rmse1) 

plt.scatter(test,predictions,color="red")
plt.title("original test data time sequence and predicted test data time sequence")
plt.xlabel("original test data time sequence ")
plt.ylabel(" predicted test data time sequence")

#-------------------------------------------------------------------------------
print("PART-b \n")
p=[1,5,10,15,25]
op=[]
for j in p:
    #using auto regression model for every value in p
    model = AutoReg(train, lags=j) 
    model_fit = model.fit() 
    predictions = model_fit.predict(start=len(train), end=len(train)+len(test)-1, dynamic=False) 
    rmse1= (mean_squared_error(test, predictions))**0.5
    rmse1=rmse1.round(3)
    op.append(rmse1)
    print("Test RMSE for lag value ",j,"is", rmse1) 
#-------------------------------------------------------------------------------
print("PART-c \n")
y=250**0.5
k=2/y
for j in range(1,len(data)):
    a=pearsonr(train[j:], train[:-j])
    if a[0]>k or -a[0]<-k :
        cnt=j
    else:
        break
model = AutoReg(train, lags=cnt) 
model_fit = model.fit() 
predictions = model_fit.predict(start=len(train), end=len(train)+len(test)-1, dynamic=False) 
rmse1= (mean_squared_error(test, predictions))**0.5
rmse1=rmse1.round(3)
print("Test RMSE for lag value ",cnt,"is", rmse1) 

#-------------------------------------------------------------------------------#-------------------------------------------------------------------------------
    # part d
# Compare the optimal number of lags (p) in parts 3.b and 3.c.
print("\n3d.)")

print("the optimal lag value from part b is",p[op.index(min(op))] )
print("the optimal lag value from part c is", cnt)
#-------------------------------------------------------------------------------#-------------------------------------------------------------------------------