# Shubhanshu Agrawal
#B19058
#7987590764

#Assgnment-3

# importing required libraries
import math
import numpy as np
from scipy.stats import pearsonr
from sklearn.metrics import mean_squared_error
import pandas as pd
from matplotlib import pyplot as plt
from scipy import stats
import statistics
from sklearn.decomposition import PCA
from statsmodels.graphics.tsaplots import plot_acf
import statsmodels.api as sm 
from sklearn import metrics
from statsmodels.tsa.ar_model import AutoReg
from sklearn.cluster import KMeans 
from sklearn.mixture import GaussianMixture
from sklearn.cluster import DBSCAN

import scipy as sp
from scipy import spatial as spatial
# reading csv file with the help of panda
train_data=pd.read_csv(r"mnist-tsne-train.csv")
test_data=pd.read_csv(r"mnist-tsne-test.csv")

#-------------------------------------------------------------------------------
print("QUESTION-1 :- \n")

print("\npart-1")
kmeans = KMeans(n_clusters=10,random_state=42) #defining the number of cluster
kmeans.fit(train_data.iloc[:,0:2]) #fitting the training data
kmeans_prediction = kmeans.predict(train_data.iloc[:,0:2]) # predicting the training data

plt.scatter(train_data["dimention 1"],train_data["dimension 2"],c=kmeans_prediction) # plotting the scatter graph
kcluster_centers=kmeans.cluster_centers_ #cluster center 
plt.scatter(kcluster_centers[:,0],kcluster_centers[:,1],color="black")
plt.title("Train data points with different colours for each cluster with clustr ceter in black color")
plt.ylabel("dimension-2")
plt.xlabel(" dimension-1")
plt.show()

#-------------------------------------------------------------------------------
print("\npart-2 \n")
#function for purity score
def purity_score(y_true,y_pred):
    # compute contingency matrix (also called confusion matrix)
    contingency_matrix = metrics.cluster.contingency_matrix(y_true, y_pred)
    # return purity
    return np.sum(np.amax(contingency_matrix, axis=0)) / np.sum(contingency_matrix)
purity_score_train=purity_score(train_data["labels"],kmeans_prediction ) # calculating purity-score for train data 
print("the purity score after train examples are assigned to clusters.",purity_score_train)
#-------------------------------------------------------------------------------
print("\npart-3")
kmeans_prediction_test = kmeans.predict(test_data.iloc[:,0:2]) # predictingthe test data

plt.scatter(test_data["dimention 1"],test_data["dimention 2"],c=kmeans_prediction_test)
kcluster_centers=kmeans.cluster_centers_
plt.scatter(kcluster_centers[:,0],kcluster_centers[:,1],color="black") #satter plot for test data
plt.title("Test data points with different colours for each cluster with clustr ceter in black color")
plt.ylabel("dimension-2")
plt.xlabel(" dimension-1")
plt.show()

#-------------------------------------------------------------------------------
print("\npart-4 \n")

purity_score_test=purity_score(test_data["labels"],kmeans_prediction_test ) #purity-score for test data
print("the purity score after test examples are assigned to clusters.",purity_score_test)
#-------------------------------------------------------------------------------
print("QUESTION-2 :- \n")

print("\npart-1")
K = 10
gmm = GaussianMixture(n_components = K,random_state=42) #defining number of cluster in gmm
gmm.fit(train_data.iloc[:,0:2]) #fitting the training data in gmm
GMM_prediction = gmm.predict(train_data.iloc[:,0:2]) # predicting the training data

plt.scatter(train_data["dimention 1"],train_data["dimension 2"],c=GMM_prediction) # plotting the scatter plot
gmm_cluster_centers=gmm.means_
plt.scatter(gmm_cluster_centers[:,0],gmm_cluster_centers[:,1],color="black")
plt.title("Train data points with different colours for each cluster with clustr ceter in black color for GMM")
plt.ylabel("dimension-2")
plt.xlabel(" dimension-1")
plt.show()

#-------------------------------------------------------------------------------

print("\npart-2 \n")
purity_score_train_gmm=purity_score(train_data["labels"], GMM_prediction) #calculating gmm purity scorefor train data 
print("The purity score after training examples are assigned to clusters. ",purity_score_train_gmm)
#-------------------------------------------------------------------------------
print("\npart-3 \n")
GMM_prediction_test = gmm.predict(test_data.iloc[:,0:2]) #predicting test data 

plt.scatter(test_data["dimention 1"],test_data["dimention 2"],c=GMM_prediction_test)
gmm_cluster_centers=gmm.means_
plt.scatter(gmm_cluster_centers[:,0],gmm_cluster_centers[:,1],color="black")
plt.title("Test data points with different colours for each cluster with clustr ceter in black color for GMM")
plt.ylabel("dimension-2")
plt.xlabel(" dimension-1")
plt.show()

#-------------------------------------------------------------------------------
print("\npart-4 \n")
purity_score_test_gmm=purity_score(test_data["labels"], GMM_prediction_test) #calculating gmm purity-score of test data 

print("the purity score after test examples are assigned to clusters",purity_score_test_gmm)
#-------------------------------------------------------------------------------

print("QUESTION-3 :- \n")
print("\npart-1")

dbscan_model=DBSCAN(eps=5, min_samples=10).fit(train_data.iloc[:,0:2]) #
DBSCAN_predictions = dbscan_model.labels_
plt.scatter(train_data["dimention 1"],train_data["dimension 2"],c=DBSCAN_predictions ,cmap="rainbow")

plt.title("Train data points with different colours for each cluster with clustr ceter in black color for DBSCAN")
plt.ylabel("dimension-2")
plt.xlabel(" dimension-1")
plt.show()
#-------------------------------------------------------------------------------
print("\npart-2")
purity_score_train_dbscan=purity_score(train_data["labels"],DBSCAN_predictions) #calculating purity score in dbscan for train data
print("The purity score after training examples are assigned to clusters.",purity_score_train_dbscan) 

#-------------------------------------------------------------------------------

print("\npart-3 \n")


def dbscan_predict(dbscan_model, X_new, metric=spatial.distance.euclidean):
    # Result is noise by default
    y_new = np.ones(shape=len(X_new), dtype=int)*-1 
    # Iterate all input samples for a label
    for j, x_new in enumerate(X_new):
    # Find a core sample closer than EPS
        for i, x_core in enumerate(dbscan_model.components_):
            if metric(x_new, x_core) < dbscan_model.eps:
                # Assign label of x_core to x_new
                y_new[j] =dbscan_model.labels_[dbscan_model.core_sample_indices_[i]]
                 
                break
    return y_new
dbtest = dbscan_predict(dbscan_model, np.array(test_data.iloc[:,0:2]), metric =spatial.distance.euclidean)
#predictng the test data
plt.scatter(test_data["dimention 1"],test_data["dimention 2"],c=dbtest)
#plotting the scatter curve
plt.title("Test data points with different colours for each cluster with clustr ceter in black color for dbtest")
plt.ylabel("dimension-2")
plt.xlabel(" dimension-1")
plt.show()

#-------------------------------------------------------------------------------
print("\npart-4 \n")

purity_score_test_dbscan=purity_score(test_data["labels"],dbtest) #calculating purity score in dbscan for train data
print("The purity score after training examples are assigned to clusters.",purity_score_test_dbscan)

#-------------------------------------------------------------------------------

print("\n        BONUS-QUESTION")

print("\nquestion-1")

data_samples=[2,5,8,12,18,20]
kmean_dist=[]
gmm_like=[]
for u in data_samples:
    kmeans = KMeans(n_clusters=u,random_state=42)
    kmeans.fit(train_data.iloc[:,0:2])
    kmean_dist.append(kmeans.inertia_)
    gmm = GaussianMixture(n_components = u,random_state=42)
    gmm.fit(train_data.iloc[:,0:2])
    gmm_like.append(gmm.lower_bound_)
            
    
plt.plot(data_samples,kmean_dist,color="red")
plt.title('Elbow Method')
plt.xlabel('Number of clusters in kmeans')
plt.ylabel('dist')
plt.show()

plt.plot(data_samples,gmm_like,color="cyan")
plt.title('Elbow Method')
plt.xlabel('Number of clusters in gmm')
plt.ylabel('likelihood')
for u in data_samples:
    print("\nFor value of k -:",u ,"\n")
    print("\npart-1")
    kmeans = KMeans(n_clusters=u,random_state=42) #defining the number of cluster
    kmeans.fit(train_data.iloc[:,0:2]) #fitting the training data
    kmeans_prediction = kmeans.predict(train_data.iloc[:,0:2]) # predicting the training data
    
    plt.scatter(train_data["dimention 1"],train_data["dimension 2"],c=kmeans_prediction) # plotting the scatter graph
    kcluster_centers=kmeans.cluster_centers_ #cluster center 
    plt.scatter(kcluster_centers[:,0],kcluster_centers[:,1],color="black")
    plt.title("Train data points with different colours for each cluster with clustr ceter in black color for value of k="+str(u))
    plt.ylabel("dimension-2")
    plt.xlabel(" dimension-1")
    plt.show()
    
    #-------------------------------------------------------------------------------
    print("\npart-2 \n")
    #function for purity score
    def purity_score(y_true,y_pred):
        # compute contingency matrix (also called confusion matrix)
        contingency_matrix = metrics.cluster.contingency_matrix(y_true, y_pred)
        # return purity
        return np.sum(np.amax(contingency_matrix, axis=0)) / np.sum(contingency_matrix)
    purity_score_train=purity_score(train_data["labels"],kmeans_prediction ) # calculating purity-score for train data 
    print("the purity score after train examples are assigned to clusters.",purity_score_train)
    #-------------------------------------------------------------------------------
    print("\npart-3")
    kmeans_prediction_test = kmeans.predict(test_data.iloc[:,0:2]) # predictingthe test data
    
    plt.scatter(test_data["dimention 1"],test_data["dimention 2"],c=kmeans_prediction_test)
    kcluster_centers=kmeans.cluster_centers_
    plt.scatter(kcluster_centers[:,0],kcluster_centers[:,1],color="black") #satter plot for test data
    plt.title("Test data points with different colours for each cluster with clustr ceter in black color for value of k="+str(u))
    plt.ylabel("dimension-2")
    plt.xlabel(" dimension-1")
    plt.show()
    
#-------------------------------------------------------------------------------------------------------------------------------------
    print("\npart-4 \n")
    
    purity_score_test=purity_score(test_data["labels"],kmeans_prediction_test ) #purity-score for test data
    print("the purity score after test examples are assigned to clusters.",purity_score_test)

for u in data_samples:
    print("\nFor value of k  :-",u)
    print("\npart-1")
  
    gmm = GaussianMixture(n_components = u,random_state=42) #defining number of cluster in gmm
    gmm.fit(train_data.iloc[:,0:2]) #fitting the training data in gmm
    GMM_prediction = gmm.predict(train_data.iloc[:,0:2]) # predicting the training data
    
    plt.scatter(train_data["dimention 1"],train_data["dimension 2"],c=GMM_prediction) # plotting the scatter plot
    gmm_cluster_centers=gmm.means_
    plt.scatter(gmm_cluster_centers[:,0],gmm_cluster_centers[:,1],color="black")
    plt.title("Train data points with different colours for each cluster with clustr ceter in black color for GMM for k"+str(u))
    plt.ylabel("dimension-2")
    plt.xlabel(" dimension-1")
    plt.show()
    
    #-------------------------------------------------------------------------------
    
    print("\npart-2 \n")
    purity_score_train_gmm=purity_score(train_data["labels"], GMM_prediction) #calculating gmm purity scorefor train data 
    print("The purity score after training examples are assigned to clusters. ",purity_score_train_gmm)
    #-------------------------------------------------------------------------------
    print("\npart-3 \n")
    GMM_prediction_test = gmm.predict(test_data.iloc[:,0:2]) #predicting test data 
    
    plt.scatter(test_data["dimention 1"],test_data["dimention 2"],c=GMM_prediction_test)
    gmm_cluster_centers=gmm.means_
    plt.scatter(gmm_cluster_centers[:,0],gmm_cluster_centers[:,1],color="black")
    plt.title("Test data points with different colours for each cluster with clustr ceter in black color for GMM for k "+str(u))
    plt.ylabel("dimension-2")
    plt.xlabel(" dimension-1")
    plt.show()
    
#------------------------------------------------------------------------------------------------------------------------------------------
    print("\npart-4 \n")
    purity_score_test_gmm=purity_score(test_data["labels"], GMM_prediction_test) #calculating gmm purity-score of test data 
    
    print("the purity score after test examples are assigned to clusters",purity_score_test_gmm)
        
        
        
    
    
#------------------------------------------------------------------------------------------------------------------------------------------
    
print("\nquestion-2")
print("\nThe parameter eps in problem misamples= 3 and eps = 1, 5 and 10")

eps=[1,5,10]
for t in eps:
    
    print("For value of eps :-",t," \n")
    print("\npart-1")

    dbscan_model=DBSCAN(eps=t, min_samples=10).fit(train_data.iloc[:,0:2]) #
    DBSCAN_predictions = dbscan_model.labels_
    plt.scatter(train_data["dimention 1"],train_data["dimension 2"],c=DBSCAN_predictions ,cmap="rainbow")
    
    plt.title("Train data points with different colours for each cluster with clustr ceter in black color for DBSCAN for value of eps "+str(t))
    plt.ylabel("dimension-2")
    plt.xlabel(" dimension-1")
    plt.show()
    #-------------------------------------------------------------------------------
    print("\npart-2")
    purity_score_train_dbscan=purity_score(train_data["labels"],DBSCAN_predictions) #calculating purity score in dbscan for train data
    print("The purity score after training examples are assigned to clusters.",purity_score_train_dbscan) 
    
    #-------------------------------------------------------------------------------
    
    print("\npart-3 \n")
    dbtest = dbscan_predict(dbscan_model, np.array(test_data.iloc[:,0:2]), metric =spatial.distance.euclidean)
    #predictng the test data
    plt.scatter(test_data["dimention 1"],test_data["dimention 2"],c=dbtest)
    #plotting the scatter curve
    plt.title("Test data points with different colours for each cluster with clustr ceter in black color for dbtest for value of eps "+str(t))
    plt.ylabel("dimension-2")
    plt.xlabel(" dimension-1")
    plt.show()
    
    #-------------------------------------------------------------------------------
    print("\npart-4 \n")
    
    purity_score_test_dbscan=purity_score(test_data["labels"],dbtest) #calculating purity score in dbscan for train data
    print("The purity score after training examples are assigned to clusters.",purity_score_test_dbscan)

#-------------------------------------------------------------------------------
    

min_samples=[1,10,30,50]
for t in min_samples:
    
    print("For value of min_samples :-",t," \n")
    print("\npart-1")

    dbscan_model=DBSCAN(eps=5, min_samples=t).fit(train_data.iloc[:,0:2]) #
    DBSCAN_predictions = dbscan_model.labels_
    plt.scatter(train_data["dimention 1"],train_data["dimension 2"],c=DBSCAN_predictions ,cmap="rainbow")
    
    plt.title("Train data points with different colours for each cluster with clustr ceter in black color for DBSCAN for value of min_saples "+str(t))
    plt.ylabel("dimension-2")
    plt.xlabel(" dimension-1")
    plt.show()
    #-------------------------------------------------------------------------------
    print("\npart-2")
    purity_score_train_dbscan=purity_score(train_data["labels"],DBSCAN_predictions) #calculating purity score in dbscan for train data
    print("The purity score after training examples are assigned to clusters.",purity_score_train_dbscan) 
    
    #-------------------------------------------------------------------------------
    
    print("\npart-3 \n")
    dbtest = dbscan_predict(dbscan_model, np.array(test_data.iloc[:,0:2]), metric =spatial.distance.euclidean)
    #predictng the test data
    plt.scatter(test_data["dimention 1"],test_data["dimention 2"],c=dbtest)
    #plotting the scatter curve
    plt.title("Test data points with different colours for each cluster with clustr ceter in black color for dbtest for value of min_samples "+str(t))
    plt.ylabel("dimension-2")
    plt.xlabel(" dimension-1")
    plt.show()
    
    #-------------------------------------------------------------------------------
    print("\npart-4 \n")
    
    purity_score_test_dbscan=purity_score(test_data["labels"],dbtest) #calculating purity score in dbscan for train data
    print("The purity score after training examples are assigned to clusters.",purity_score_test_dbscan)

#-------------------------------------------------------------------------------


#-------------------------------------------------------------------------------






